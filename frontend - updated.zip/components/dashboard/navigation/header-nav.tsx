"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { ThemeToggle } from "@/components/theme-toggle"
import { Bell, LogOut } from "lucide-react"

export function HeaderNav({
  notificationsCount,
  onLogout,
}: {
  notificationsCount: number
  onLogout: () => void
}) {
  return (
    <header className="bg-card border-b border-border p-4 lg:p-6">
      <div className="max-w-[1920px] mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <SidebarTrigger />
          <img
            src="/hey-paytm-logo.png"
            alt="Hey Paytm logo"
            className="w-10 h-10 lg:w-12 lg:h-12 xl:w-14 xl:h-14 rounded-xl shadow-sm"
          />
          <div>
            <h1 className="font-sans font-bold text-lg lg:text-xl xl:text-2xl text-foreground text-balance">
              Hey Paytm Dashboard
            </h1>
            <p className="text-xs lg:text-sm text-muted-foreground">Restaurant Management System</p>
          </div>
        </div>
        <div className="flex items-center gap-3 lg:gap-4 flex-wrap sm:flex-nowrap">
          <ThemeToggle />
          <div className="relative">
            <Button variant="outline" size="sm" className="rounded-full bg-transparent text-sm lg:text-base">
              <Bell className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
              Notifications
              {notificationsCount > 0 && (
                <Badge variant="destructive" className="ml-2 px-1 py-0 text-xs">
                  {notificationsCount}
                </Badge>
              )}
            </Button>
          </div>
          <div className="text-left sm:text-right">
            <p className="text-sm lg:text-base font-medium">Spice Garden Restaurant</p>
            <p className="text-xs lg:text-sm text-muted-foreground">Online • 12 Tables Active</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onLogout}
            className="rounded-full bg-transparent text-sm lg:text-base"
          >
            <LogOut className="w-4 h-4 lg:w-5 lg:h-5 mr-2" />
            Logout
          </Button>
        </div>
      </div>
    </header>
  )
}

export default HeaderNav
