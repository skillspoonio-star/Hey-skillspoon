"use client"

import { Badge } from "@/components/ui/badge"
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar"
import {
  Activity,
  Store,
  ShoppingBag,
  Truck,
  CalendarCheck,
  ChefHat,
  TableIcon,
  ClipboardList,
  CreditCard,
  BarChart3,
  ListTree,
  Boxes,
  Users,
  LogOut,
} from "lucide-react"

type ActiveKey =
  | "orders"
  | "counter"
  | "takeaway"
  | "reservations"
  | "kitchen"
  | "tables"
  | "assignment"
  | "payment"
  | "analytics"
  | "menu"
  | "staff"
  | "inventory"
  | "delivery"

export function SidebarNav({
  active,
  onSelect,
  liveOrdersBadge,
  onLogout,
}: {
  active: ActiveKey
  onSelect: (key: ActiveKey) => void
  liveOrdersBadge: number
  onLogout: () => void
}) {
  return (
    <Sidebar collapsible="icon" variant="inset" className="border-r">
      <SidebarHeader>
        <div className="px-2 py-1 flex items-center justify-start gap-2">
          <img src="/hey-paytm-logo.png" alt="Hey Paytm logo" className="w-8 h-8 rounded-lg shadow-sm" />
          <div className="text-sm group-data-[collapsible=icon]:hidden">
            <div className="font-semibold">Hey Paytm</div>
            <div className="text-xs text-muted-foreground">Dashboard</div>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {[
            { key: "orders", label: "Live Orders", icon: Activity, badge: liveOrdersBadge },
            { key: "counter", label: "Counter Orders", icon: Store },
            { key: "takeaway", label: "Takeaway", icon: ShoppingBag },
            { key: "delivery", label: "Delivery Orders", icon: Truck },
            { key: "reservations", label: "Reservations", icon: CalendarCheck },
            { key: "kitchen", label: "Kitchen Display", icon: ChefHat },
            { key: "tables", label: "Table Management", icon: TableIcon },
            { key: "assignment", label: "Table Assignment", icon: ClipboardList },
            { key: "payment", label: "Payment Confirmation", icon: CreditCard },
            { key: "analytics", label: "Analytics", icon: BarChart3 },
            { key: "menu", label: "Menu Management", icon: ListTree },
            { key: "inventory", label: "Inventory", icon: Boxes },
            { key: "staff", label: "Staff", icon: Users },
          ].map((item) => (
            <SidebarMenuItem key={item.key}>
              <SidebarMenuButton
                isActive={active === (item.key as ActiveKey)}
                onClick={() => onSelect(item.key as ActiveKey)}
                title={item.label}
                className="justify-start gap-3 data-[active=true]:border-l-2 data-[active=true]:border-primary data-[active=true]:bg-primary/10"
              >
                <item.icon className="w-4 h-4" aria-hidden="true" />
                <span className="group-data-[collapsible=icon]:hidden">{item.label}</span>
                {typeof (item as any).badge !== "undefined" && (item as any).badge > 0 && (
                  <Badge variant="destructive" className="ml-auto group-data-[collapsible=icon]:hidden">
                    {(item as any).badge}
                  </Badge>
                )}
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={onLogout}
              title="Logout"
              className="justify-start gap-3 hover:bg-destructive/10"
            >
              <LogOut className="w-4 h-4" aria-hidden="true" />
              <span className="group-data-[collapsible=icon]:hidden">Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
    </Sidebar>
  )
}

export default SidebarNav
