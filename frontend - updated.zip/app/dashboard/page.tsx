"use client"

import { SidebarInset } from "@/components/ui/sidebar"

import { SidebarRail } from "@/components/ui/sidebar"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import { OrderCard } from "@/components/order-card"
import { AnalyticsCard } from "@/components/analytics-card"
import { MenuManagement } from "@/components/menu-management"
import { TableManagement } from "@/components/table-management"
import { KitchenDisplay } from "@/components/kitchen-display"
import { StaffManagement } from "@/components/staff-management"
import { PaymentConfirmation } from "@/components/payment-confirmation"
import { TableAssignmentPage } from "@/components/table-assignment-page"
import { Clock, Users, DollarSign, TrendingUp } from "lucide-react"
import { useOrderManager } from "@/hooks/use-order-manager"
import { TakeawayManagement } from "@/components/takeaway-management"
import { ReservationManagement } from "@/components/reservation-management"
import { CounterOrderManagement } from "@/components/counter-order-management"
import { SectionHeader } from "@/components/section-header"
import { SidebarProvider } from "@/components/ui/sidebar"
import { InventoryManagement } from "@/components/inventory-management"
import { DeliveryManagement } from "@/components/delivery-management"
import { HeaderNav } from "@/components/dashboard/navigation/header-nav"
import { SidebarNav } from "@/components/dashboard/navigation/sidebar-nav"

export default function RestaurantDashboard() {
  const router = useRouter()
  const { orders, updateOrderStatus, getOrdersByStatus, getAnalytics } = useOrderManager()

  const [authChecked, setAuthChecked] = useState(false)

  useEffect(() => {
    let mounted = true

    async function verifyToken() {
      const token = localStorage.getItem("adminAuth")
      if (!token) {
        router.push("/admin/login")
        return
      }

      try {
        const base = process.env.NEXT_PUBLIC_BACKEND_URL
        console.log("Using backend URL:", base)
        const res = await fetch(`${base}/api/auth/verify`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        })
        console.log("Verification response status:", res)

        if (!mounted) return

        if (!res.ok) {
          // verification failed
          localStorage.removeItem("adminAuth")
          router.push("/admin/login")
          return
        }

        // token valid
        setAuthChecked(true)
      } catch (err) {
        // network or unexpected error - treat as unauthenticated
        localStorage.removeItem("adminAuth")
        router.push("/admin/login")
      }
    }

    verifyToken()

    return () => {
      mounted = false
    }
  }, [router])

  const [notifications, setNotifications] = useState<string[]>([
    "New voice order from Table 12",
    "Payment completed for Table 5",
    "New takeaway order #TK001 received",
    "Table reservation confirmed for 7:30 PM",
  ])

  const [active, setActive] = useState<
    | "orders"
    | "counter"
    | "takeaway"
    | "reservations"
    | "kitchen"
    | "tables"
    | "assignment"
    | "payment"
    | "analytics"
    | "menu"
    | "staff"
    | "inventory"
    | "delivery"
  >("orders")

  const handleLogout = () => {
    localStorage.removeItem("adminAuth")
    router.push("/admin/login")
  }

  const handleOrderStatusUpdate = (
    orderId: string | number,
    newStatus: "pending" | "preparing" | "ready" | "served" | "cancelled",
  ) => {
    updateOrderStatus(orderId, newStatus)
    const order = orders.find((o) => String(o.id) === String(orderId))
    if (order) {
      setNotifications((prev) => [`Table ${order.tableNumber} order marked as ${newStatus}`, ...prev.slice(0, 4)])
    }
  }

  const pendingOrders = getOrdersByStatus("pending")
  const preparingOrders = getOrdersByStatus("preparing")
  const readyOrders = getOrdersByStatus("ready")
  const analytics = getAnalytics()

  const liveOrdersBadge = pendingOrders.length + preparingOrders.length

  if (!authChecked) {
    return null
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen bg-background flex">
        <SidebarNav
          active={active}
          onSelect={setActive as any}
          liveOrdersBadge={liveOrdersBadge}
          onLogout={handleLogout}
        />
        <SidebarRail />
        <SidebarInset>
          <HeaderNav notificationsCount={notifications.length} onLogout={handleLogout} />
          {/* Body */}
          <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 py-6 lg:py-8">
            <Tabs value={active} className="space-y-6 lg:space-y-8" onValueChange={(v) => setActive(v as any)}>
              <TabsContent value="orders" className="space-y-6">
                <SectionHeader title="Live Orders" subtitle="Monitor and manage real-time orders" />
                <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 xl:gap-8">
                  <Card className="rounded-xl border shadow-sm">
                    <CardContent className="p-5 lg:p-6 xl:p-8">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm lg:text-base text-muted-foreground">Pending Orders</p>
                          <p className="text-2xl lg:text-3xl xl:text-4xl font-bold text-destructive">
                            {pendingOrders.length}
                          </p>
                        </div>
                        <Clock className="w-8 h-8 lg:w-10 lg:h-10 xl:w-12 xl:h-12 text-destructive" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="rounded-xl border shadow-sm">
                    <CardContent className="p-5 lg:p-6 xl:p-8">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm lg:text-base text-muted-foreground">Preparing</p>
                          <p className="text-2xl lg:text-3xl xl:text-4xl font-bold text-foreground">
                            {preparingOrders.length}
                          </p>
                        </div>
                        <Users className="w-8 h-8 lg:w-10 lg:h-10 xl:w-12 xl:h-12 text-secondary-foreground" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="rounded-xl border shadow-sm">
                    <CardContent className="p-5 lg:p-6 xl:p-8">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm lg:text-base text-muted-foreground">Ready to Serve</p>
                          <p className="text-2xl lg:text-3xl xl:text-4xl font-bold text-primary">
                            {readyOrders.length}
                          </p>
                        </div>
                        <TrendingUp className="w-8 h-8 lg:w-10 lg:h-10 xl:w-12 xl:h-12 text-primary" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="rounded-xl border shadow-sm">
                    <CardContent className="p-5 lg:p-6 xl:p-8">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm lg:text-base text-muted-foreground">Today's Revenue</p>
                          <p className="text-2xl lg:text-3xl xl:text-4xl font-bold text-accent">
                            ₹{analytics.totalRevenue}
                          </p>
                        </div>
                        <DollarSign className="w-8 h-8 lg:w-10 lg:h-10 xl:w-12 xl:h-12 text-accent" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 lg:gap-8">
                  <div>
                    <h3 className="font-semibold text-lg lg:text-xl mb-4 text-destructive">
                      Pending Orders ({pendingOrders.length})
                    </h3>
                    <div className="space-y-4">
                      {pendingOrders.map((order) => (
                        <OrderCard key={String(order.id)} order={order} onStatusUpdate={handleOrderStatusUpdate} />
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg lg:text-xl mb-4 text-foreground">
                      Preparing ({preparingOrders.length})
                    </h3>
                    <div className="space-y-4">
                      {preparingOrders.map((order) => (
                        <OrderCard key={String(order.id)} order={order} onStatusUpdate={handleOrderStatusUpdate} />
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg lg:text-xl mb-4 text-primary">
                      Ready to Serve ({readyOrders.length})
                    </h3>
                    <div className="space-y-4">
                      {readyOrders.map((order) => (
                        <OrderCard key={String(order.id)} order={order} onStatusUpdate={handleOrderStatusUpdate} />
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="counter" className="space-y-6">
                <SectionHeader title="Counter Orders" subtitle="Walk-in orders and billing" />
                <CounterOrderManagement />
              </TabsContent>

              <TabsContent value="takeaway" className="space-y-6">
                <SectionHeader title="Takeaway" subtitle="Manage pickup orders" />
                <TakeawayManagement />
              </TabsContent>

              <TabsContent value="delivery" className="space-y-6">
                <SectionHeader title="Delivery Orders" subtitle="Track and manage deliveries" />
                <DeliveryManagement />
              </TabsContent>

              <TabsContent value="reservations" className="space-y-6">
                <SectionHeader title="Reservations" subtitle="Handle bookings and guest info" />
                <ReservationManagement />
              </TabsContent>

              <TabsContent value="kitchen" className="space-y-6">
                <SectionHeader title="Kitchen Display" subtitle="Order queue for the kitchen" />
                <KitchenDisplay orders={orders} onStatusUpdate={handleOrderStatusUpdate} />
              </TabsContent>

              <TabsContent value="tables" className="space-y-6">
                <SectionHeader title="Table Management" subtitle="Layout, status, and seating" />
                <TableManagement orders={orders} />
              </TabsContent>

              <TabsContent value="assignment" className="space-y-6">
                <SectionHeader title="Table Assignment" subtitle="Assign and optimize seating" />
                <TableAssignmentPage />
              </TabsContent>

              <TabsContent value="payment" className="space-y-6">
                <SectionHeader title="Payment Confirmation" subtitle="Verify bills and settlements" />
                <PaymentConfirmation />
              </TabsContent>

              <TabsContent value="analytics" className="space-y-6">
                <SectionHeader title="Analytics" subtitle="Sales, items, and trends" />
                <AnalyticsCard orders={orders} />
              </TabsContent>

              <TabsContent value="menu" className="space-y-6">
                <SectionHeader title="Menu Management" subtitle="Items, categories, and availability" />
                <MenuManagement />
              </TabsContent>

              <TabsContent value="inventory" className="space-y-6">
                <SectionHeader title="Inventory" subtitle="Stock and low-supply alerts" />
                <InventoryManagement />
              </TabsContent>

              <TabsContent value="staff" className="space-y-6">
                <SectionHeader title="Staff" subtitle="Team overview and roles" />
                <StaffManagement />
              </TabsContent>
            </Tabs>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  )
}
